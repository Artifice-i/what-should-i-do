# What Should I Do? — V1
A private, dependency-free activity recommender. Nothing leaves this computer.

## Launch
Double-click Launch.cmd. Keep its terminal window open while using the app.
Alternatively, open a terminal in this folder, run npm start, and visit http://127.0.0.1:4173.
Node.js 18 or newer is required. No npm install is needed.
Close the terminal (or press Ctrl+C) to stop the server.
If the port is occupied by this app, use the already-open app. Otherwise stop the conflicting process; this app will not stop other programs.

## Use
Adjust only the fields that matter. Fine-tune the vibe contains optional mental and physical preferences.
Find my next thing returns one primary and up to two alternatives.
Not feeling it replaces that card and excludes it until page refresh or Clear session rejections.
Sounds good acknowledges your choice. It does not book, message, launch, or purchase anything.

## Edit the library
Edit dist/activities.js. Each row is documented above the data. Keep IDs unique and stable.
Refresh the browser after editing. No compilation step.
Activity costs assume existing equipment/access and are estimates, not live prices.

## Scoring
dist/engine.js is independent of the interface.
Hard filters: time, budget, chosen location/company, rejected IDs, and energy required no more than two points above current energy.
When unwell, only restful indoor activities with minimal movement qualify; sick mode caps required energy at four.
Ranking: base 50; minus 4 per energy difference; minus 12 per mental/physical level difference when specified; plus 15 for mood, 22 for an interest, and up to 6 for using available time.
Alternative selection applies a 9-point penalty per already-selected category to encourage variety.
Limits never relax silently. Restrictive combinations can produce fewer than three matches.
Recommendations are deterministic and do not learn from approvals.

## Test and recovery
Run npm test for built-in Node tests. No test dependencies.
The Git repository contains implementation and tested-V1 checkpoints.
Use git log --oneline to view checkpoints. There is no remote repository.

## Scope
44 curated activities. No location, weather, calendar, model, account, database, tracking, or external requests.
Feedback lives in page memory and resets on refresh. Availability, equipment, friends, transport, and opening hours are not checked.
This is an activity picker, not medical guidance.
Optional browser-agent support uses the current visible form when the browser provides WebMCP; it is inert otherwise.

## Possible V2 improvements
- Personal activity editor and equipment/access preferences.
- Optional local favorites/history and learning from feedback.
- Better duration variants and more activities for restrictive combinations.

## Celebration update
Sounds good triggers a button-centered confetti burst and a short locally synthesized fanfare. Sound on/off is above the recommendation cards and resets to on when the page reloads. Reduced-motion preferences suppress confetti. No new dependencies.

